# backendcap2
Accounts Management
    Add
    Edit
    Get
    Get All
Grade Management
    Add
    Edit
    Get
    GetAll
Class Management
    Add
    Edit
    Get
    GetAll
Student Management
    Import
    Edit
    Get
    GetAll
Course Management
    Import
    Edit
    Get
    GetAll
